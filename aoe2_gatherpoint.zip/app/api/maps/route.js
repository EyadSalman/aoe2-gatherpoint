// app/api/maps/route.js
import { NextResponse } from "next/server";
import { dbConnect } from "@/lib/dbConnect";
import Map from "@/models/Map";

export async function GET(req) {
  await dbConnect();
  const url = new URL(req.url);
  const page = parseInt(url.searchParams.get("page") || "1");
  const limit = parseInt(url.searchParams.get("limit") || "20");
  const type = url.searchParams.get("type");
  const difficulty = url.searchParams.get("difficulty");
  const search = url.searchParams.get("search");

  const filter = { isActive: true };
  if (type && type !== "All") filter.type = type;
  if (difficulty) filter.difficulty = difficulty;
  if (search) {
    filter.$or = [
      { name: { $regex: search, $options: "i" } },
      { description: { $regex: search, $options: "i" } },
      { features: { $regex: search, $options: "i" } },
    ];
  }

  try {
    const maps = await Map.find(filter)
      .sort({ name: 1 })
      .limit(limit)
      .skip((page - 1) * limit);
    const total = await Map.countDocuments(filter);

    return NextResponse.json({
      success: true,
      data: maps,
      pagination: { current: page, pages: Math.ceil(total / limit), total },
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, message: "Error fetching maps", error: error.message },
      { status: 500 }
    );
  }
}
