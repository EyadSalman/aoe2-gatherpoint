import { NextResponse } from "next/server"

export async function GET() {
  const recentTournaments = [
    { name: "Winter Championship 2024", winners: [{ division: "2400+", player: "NeoZz", rating: 2564 }] },
    { name: "Autumn Cup 2024", winners: [{ division: "2400+", player: "Rayz", rating: 2492 }] },
  ]
  return NextResponse.json({ success: true, data: recentTournaments })
}
