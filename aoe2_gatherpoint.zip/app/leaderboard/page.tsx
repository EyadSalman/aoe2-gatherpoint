"use client"

import { useEffect, useState } from "react"
import { Navigation } from "@/components/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Crown, Medal, Trophy } from "lucide-react"

type TournamentWinner = {
  division: string
  player: string
  rating: number
}

type TournamentResult = {
  name: string
  date: string
  winners: TournamentWinner[]
}

export default function LeaderboardPage() {
  const [recentTournaments, setRecentTournaments] = useState<TournamentResult[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch("http://localhost:5000/api/leaderboard/recent")
      .then(res => res.json())
      .then(data => {
        if (data && data.data) setRecentTournaments(data.data)
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }, [])

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <div className="container mx-auto py-8 px-4">
        <div className="mb-8">
          <h1 className="text-4xl font-bold tracking-tight">Community Leaderboard</h1>
          <p className="mt-2 text-lg text-muted-foreground">
            Recent tournament results and top player performances
          </p>
        </div>

        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <Calendar className="h-6 w-6" />
            Recent Tournament Results
          </h2>

          {loading && <p className="text-muted-foreground">Loading results...</p>}

          {!loading && recentTournaments.length === 0 && (
            <p className="text-muted-foreground">No recent tournaments available.</p>
          )}

          <div className="space-y-6">
            {recentTournaments.map((t, i) => (
              <Card key={i}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-xl">{t.name}</CardTitle>
                      <CardDescription>{t.date}</CardDescription>
                    </div>
                    <Trophy className="h-6 w-6 text-yellow-500" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                    {t.winners.map((winner, wi) => (
                      <div
                        key={wi}
                        className="flex items-center space-x-3 p-3 rounded-lg bg-muted/50"
                      >
                        <div className="flex-shrink-0">
                          {wi === 0 && <Crown className="h-5 w-5 text-yellow-500" />}
                          {wi === 1 && <Medal className="h-5 w-5 text-gray-400" />}
                          {wi === 2 && <Medal className="h-5 w-5 text-amber-600" />}
                          {wi === 3 && <Trophy className="h-5 w-5 text-muted-foreground" />}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium truncate">{winner.player}</div>
                          <div className="text-xs text-muted-foreground">{winner.division}</div>
                        </div>
                        <Badge variant="secondary" className="text-xs">
                          {winner.rating}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
