// middleware.js
import { NextResponse } from "next/server";
import jwt from "jsonwebtoken";
import { dbConnect } from "@/lib/dbConnect";
import User from "@/models/User";

const PUBLIC_ROUTES = [
  "/api/auth/login",
  "/api/auth/register",
  "/api/leaderboard",
];

export async function middleware(req) {
  const { pathname } = req.nextUrl;

  // ✅ Allow public routes without token
  if (PUBLIC_ROUTES.some((p) => pathname.startsWith(p))) {
    return NextResponse.next();
  }

  const token = req.cookies.get("token")?.value;
  if (!token) {
    return NextResponse.json(
      { success: false, message: "Access denied. No token provided." },
      { status: 401 }
    );
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    await dbConnect();
    const user = await User.findById(decoded.id);

    if (!user || !user.isActive) {
      return NextResponse.json(
        { success: false, message: "Invalid or inactive user." },
        { status: 401 }
      );
    }

    // ✅ Attach user ID to request header (available in API routes)
    const res = NextResponse.next();
    res.headers.set("x-user-id", user._id.toString());
    res.headers.set("x-user-role", user.role);
    return res;
  } catch (err) {
    return NextResponse.json(
      { success: false, message: "Invalid or expired token." },
      { status: 401 }
    );
  }
}

export const config = {
  matcher: ["/api/:path*"], // runs for all API routes
};
